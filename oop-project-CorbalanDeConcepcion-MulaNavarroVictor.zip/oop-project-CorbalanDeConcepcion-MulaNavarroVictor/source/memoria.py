from canciones import Cancion
from usuarios import Usuario, UsuarioPremium
from persistencia import GestorPersistencia
from listas import Catalogo, CatalogoPersonal, Lista
import json, csv


class Memoria:
    def __init__(self, ruta="../db/"):

        self.ruta = ruta

        self.__gp = GestorPersistencia()
        self.cargar_catalogo_generico()

        # ESTABLEZCO LOS USUARIOS
        usuarios: dict[str : "Usuario"] = dict()
        for usuario_info in self.gp().leer_json(f"{self.ruta}usuarios.json"):

            if usuario_info["Tipo usuario"] == "REGULAR":
                usuario = Usuario()
                usuario.diccionario_a_objeto(usuario_info)

            elif usuario_info["Tipo usuario"] == "PREMIUM":
                usuario = UsuarioPremium()
                usuario.diccionario_a_objeto(usuario_info)
                usuario.set_catalogo_personal(self.cargar_catalogo_personal(usuario))

            usuario.set_listas_reproduccion(self.cargar_listas_reproduccion(usuario))
            usuarios[usuario.get_nombre_usuario()] = usuario
        self._usuarios = usuarios


    def __str__(self):
        """Devuelve la memoria cargada, aunque solo se utiliza a efectos del administrador"""
        msg = "===================================MEMORIA=========================================\n"
        msg += f"\t ·USUARIOS = \n\n"
        for usuario in self.get_usuarios().values():
            msg += f"\t{usuario}\n"
        msg += "\n"

        msg += f"\t ·CATÁLOGO GENÉRICO = [\n"
        for cancion in self.get_catalogo_generico().get_lista_canciones():
            msg += f"\t\t{cancion}\n"
        msg += "\n"
        return msg

    def gp(self) -> 'GestorPersistencia':
        return self.__gp

    def get_usuarios(self):
        return self._usuarios

    def get_catalogo_generico(self):
        return self._catalogo_generico

    def cargar_catalogo_personal(self, usuario:'Usuario'):
        lista_canciones_catalogo_personal = list()
        for cancion_info in self.gp().leer_csv(f"{self.ruta}catalogos_personales/{usuario.get_nombre_usuario()}.csv"):
            cancion = Cancion()
            cancion.diccionario_a_objeto(cancion_info)
            lista_canciones_catalogo_personal.append(cancion)

        catalogo:CatalogoPersonal =  CatalogoPersonal(lista_canciones_catalogo_personal)
        return catalogo

    def guardar_catalogo_personal(self, usuario:'Usuario'):
        if (usuario.comprobar_acceso_premium() and usuario.get_catalogo_personal()):
            self.gp().resetear_csv_manteniendo_cabeceras(f"{self.ruta}catalogos_personales/{usuario.get_nombre_usuario()}.csv")
            for cancion_info in usuario.get_catalogo_personal().objeto_a_diccionario():
                self.gp().guardar_csv(
                    contenido=cancion_info,
                    ruta=f"{self.ruta}catalogos_personales/{usuario.get_nombre_usuario()}.csv",
                )

    def cargar_listas_reproduccion(self, usuario:'Usuario'):

        listas_reproduccion_usuario : list[Lista] = []
        listas_info = self.gp().leer_json(f"{self.ruta}listas_reproduccion/{usuario.get_nombre_usuario()}.json")

        for lista_info in listas_info:

            for lista_info in self.gp().leer_json(f"{self.ruta}listas_reproduccion/{usuario.get_nombre_usuario()}.json"):
                
                lista = Lista()
                lista.diccionario_a_objeto(lista_info)

                canciones_recuperadas = []
                if "Lista canciones" in lista_info:
                    for cancion_id in lista_info["Lista canciones"]:

                        cancion = self.get_catalogo_generico().devolver_cancion_por_id(cancion_id)
                        if not cancion and usuario.comprobar_acceso_premium():
                            cancion = usuario.get_catalogo_personal().devolver_cancion_por_id(cancion_id)
                        if cancion:
                            canciones_recuperadas.append(cancion)

                lista.set_lista_canciones(canciones_recuperadas)
                listas_reproduccion_usuario.append(lista)
            return listas_reproduccion_usuario


    def guardar_listas_reproduccion(self, usuario:'Usuario'):
        if (usuario.get_listas_reproduccion() and usuario.get_listas_reproduccion() != []):
            usuario_listas_reproduccion = list()
            for lista_reproduccion in usuario.get_listas_reproduccion():
                usuario_listas_reproduccion.append(lista_reproduccion.objeto_a_diccionario())
            self.gp().guardar_json(
                contenido= usuario_listas_reproduccion,
                ruta=f"{self.ruta}listas_reproduccion/{usuario.get_nombre_usuario()}.json",
            )

    def cargar_catalogo_generico(self):
        lista_canciones_catalogo_generico = list()
        for cancion_info in self.gp().leer_csv(f"{self.ruta}catalogo_generico.csv"):
            cancion = Cancion()
            cancion.diccionario_a_objeto(cancion_info)
            lista_canciones_catalogo_generico.append(cancion)
        self._catalogo_generico = Catalogo(lista_canciones_catalogo_generico)   

    def guardar_en_disco(self):
        """Este método se ejecuta antes de salir de la aplicación: guarda toda la memoria en el disco duro"""

        # GUARDADO DE LOS USUARIOS
        try:
            usuarios_info = list()
            for usuario in self.get_usuarios().values():
                usuarios_info.append(usuario.objeto_a_diccionario())
                self.guardar_catalogo_personal(usuario)
                self.guardar_listas_reproduccion(usuario)


            # GUARDO TODOS LOS USUARIOS COMO UN <<CONGLOMERADO>> DE USUARIOS, ES DECIR HAGO UN ÚNICO DUMP
            self.gp().guardar_json(
                contenido=usuarios_info,
                ruta=f"{self.ruta}usuarios.json"
            )

        except Exception as e:
            print(f"ERROR EN EL GUARDADO EN DISCO {e}")

        # EL CATÁLOGO GENÉRICO NO CAMBIA, ES FIJO. POR TANTO NO TENGO QUE INTERACTUAR CON ÉL EN DISCO

    def anyadir_usuario(self, usuario: "Usuario"):
        self.get_usuarios()[usuario.get_nombre_usuario()] = usuario

    def comprobar_usuario_registrado(self, nombre: str) -> bool:
        """Dado un nombre de usuario, verifica que esté en la base de datos"""
        return True if nombre in self.get_usuarios() and self.get_usuarios()[nombre] else False
        
    def comprobar_cancion_en_catalogo(self, id_cancion: str) -> bool:
        for cancion in self.get_catalogo_generico().get_lista_canciones():
            if cancion.get_identificador() == id_cancion:
                return True
        return False

    def comprobar_cancion_en_catalogo_premium(self, id_cancion: str, nombre_usuario: str):
        if self.get_usuarios()[nombre_usuario].comprobar_acceso_premium() != "PREMIUM":
            return False
        for cancion in self.get_usuarios()[nombre_usuario].get_catalogo_personal().get_lista_canciones():
            if cancion.get_identificador() == id_cancion:
                return True
        return False

    def comprobar_credenciales_validas(self, nombre: str, contrasenya: str) -> bool:
        """Comprueba que el usuario esté registrado y que la contraseña coincida con la guardada en la base de datos"""
        if self.comprobar_usuario_registrado(nombre):
            if contrasenya == self.get_usuarios()[nombre].get_contrasenya():
                return True
            print("Contraseña no válida.")
        else:
            print(f"Usuario {nombre} no registrado en la base de datos.")
        return False

    def cargar_usuario_por_nombre_y_contrasenya(self, nombre: str, contrasenya: str):
        if self.comprobar_credenciales_validas(nombre, contrasenya):
            return self.get_usuarios()[nombre]

    def crear_lista_de_reproduccion_json(self, nombre_usuario:str):
        self.gp().guardar_json([], f"{self.ruta}listas_reproduccion/{nombre_usuario}.json")

    def crear_catalogo_personal_csv(self, nombre_usuario : str):
        self.gp().escribir_keys_csv({"Nombre":None, "Artista":None, "Genero":None, "Anyo":None, "Identificador cancion":None}, f"{self.ruta}catalogos_personales/{nombre_usuario}.csv")